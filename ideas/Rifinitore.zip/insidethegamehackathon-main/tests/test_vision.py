"""Auto-eventing from video: a frame is rendered from tracking, the detector reads only its pixels, the tracker gives back tracking chunks."""

from __future__ import annotations

import time

import numpy as np
import pytest

from matchmind.live import session as S
from matchmind.live.pipeline import Intel
from matchmind.tracking.frames import iter_chunks
from matchmind.vision.detect import detect
from matchmind.vision.feed import events_for_anchoring
from matchmind.vision.render import png, render_frame, to_m, to_px
from matchmind.vision.track import VideoTracker


def test_pixels_and_pitch_coordinates_are_inverse():
    x, y = to_px(37.5, 12.25)
    assert np.allclose(to_m(x, y), (37.5, 12.25))


def test_the_detector_finds_every_player_and_the_ball_from_pixels_alone(match):
    ch = list(iter_chunks(match))[10]
    f, b = ch.frames[3], ch.ball[3]
    det = detect(render_frame(f, b, np.random.default_rng(1)))
    assert abs(len(det.home) - 11) <= 1 and abs(len(det.away) - 11) <= 1  # two players standing on each other make one blob, as in real video
    for found, truth in ((det.home, f[:11]), (det.away, f[11:])):
        assert np.linalg.norm(found[:, None, :] - truth[None], axis=2).min(axis=1).max() < 0.3  # every blob within 30 cm of a player
    assert det.ball is not None and np.hypot(*(det.ball[:2] - b[:2])) < 0.3


def test_a_tracked_stretch_of_the_match_is_close_to_the_truth(match):
    chunks = list(iter_chunks(match))[:40]
    vt = VideoTracker(chunks[0].frames[0])
    ev = events_for_anchoring([], 5)
    for ch in chunks:
        out = vt.process(ch, ev)
        assert out.frames.shape == ch.frames.shape and out.slots == ch.slots and out.first_frame == ch.first_frame
    s = vt.stats.summary()
    assert s["positionRmseCm"] < 25 and s["ballRmseCm"] < 25 and s["ballSeen"] > 0.95
    assert s["speedErrorKmh"] < 3.0


def test_a_player_the_video_no_longer_shows_is_let_go(match):
    ch = list(iter_chunks(match))[3]
    vt = VideoTracker(ch.frames[0])
    gone = ch.frames.copy()
    gone[:, 4] = np.nan  # a sending-off: slot 4 is no longer on the pitch
    out = vt.process(type(ch)(**{**ch.__dict__, "frames": gone}))
    assert np.isnan(out.frames[-1, 4, 0]) and not np.isnan(out.frames[-1, 5, 0])


def test_the_png_is_a_picture():
    img = render_frame(np.full((22, 2), np.nan), np.array([50.0, 30.0, 0.0]))
    data = png(img)
    assert data[:8] == b"\x89PNG\r\n\x1a\n" and len(data) > 100


@pytest.fixture(scope="module")
def vision_hub():
    from matchmind.vision import shared

    shared.reset()
    h = S.StreamHub(intel=Intel.load(), tick_s=0.02, max_sessions=4, vision=True)
    h.speeds = (*S.SPEEDS, 2000.0)
    h.preload(["red-card-drama"])
    yield h
    shared.reset()


def test_a_live_match_reads_its_physical_facts_from_the_video_feed(vision_hub):
    s = vision_hub.start("red-card-drama", speed=2000.0, from_minute=92.0)
    assert s.vision is not None
    t0 = time.monotonic()
    while time.monotonic() - t0 < 120 and not (s.finished_at is not None):
        time.sleep(0.1)
    assert s.finished_at is not None and s.error is None
    st = s.vision.stats()
    assert st["takenChunks"] + st["skippedChunks"] > 5, st  # every chunk reached the analyzer, from the video model or, where it had not got to, the provider
    kinds = {d["kind"] for d in vision_hub.store.docs(s.id)}
    assert "physical" in kinds or "enrichment" in kinds


def test_two_viewers_of_a_demo_share_one_reading_of_it(vision_hub):
    a = vision_hub.start("red-card-drama", speed=5.0)
    b = vision_hub.start("red-card-drama", speed=5.0)
    assert a.vision.shared is b.vision.shared  # one reader for the demo, not one per viewer
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline and len(a.vision.shared.results) < 4:
        time.sleep(0.2)
    assert len(a.vision.shared.results) >= 4
    vision_hub.stop(a.id)
    vision_hub.stop(b.id)


def test_a_chunk_the_shared_reader_has_not_reached_is_the_providers(match):
    from matchmind.tracking.frames import encode_chunk
    from matchmind.vision.feed import VisionFeed
    from matchmind.vision.shared import SharedVision

    chunks = list(iter_chunks(match))[:6]
    truth = [((c.index + 1) * 5000, f"m/{c.index:05d}", encode_chunk(c)) for c in chunks]
    idle = SharedVision("t", truth, [])  # never started: it has read nothing
    feed = VisionFeed("t", truth, [], 5, shared=idle)
    import matchmind.vision.feed as F

    F.WAIT_S = 0.1
    for _, name, _ in truth:
        feed.submit(name)
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline and feed.pending() > 0:
        time.sleep(0.05)
    assert feed.skipped == len(truth) and all(feed.blobs.exists(n) for _, n, _ in truth)  # all of them exist for the analyzer, as the provider's
    feed.close()


def test_the_baked_reading_of_a_demo_matches_the_demo(vision_hub):
    """data/vision/<demo>.pkl is made by `matchmind vision-bake`; if the demo or the simulator changes, it must be baked again."""
    from matchmind.demos import load_demos
    from matchmind.vision.shared import SharedVision

    for demo_id in load_demos():
        if not SharedVision.baked_path(demo_id).exists():
            continue
        src = vision_hub.source(demo_id)
        feed = S.VisionFeed(demo_id, [(end, f"b/{i:05d}", data) for i, (end, _, data) in enumerate(src.chunks)], src.docs, src.meta["hz"]) if hasattr(S, "VisionFeed") else None
        assert feed is not None and feed.shared.baked, f"{demo_id}: the baked reading does not fit the demo; run `uv run matchmind vision-bake {demo_id}`"
        assert len(feed.shared.results) == len(src.chunks)
        feed.close()
